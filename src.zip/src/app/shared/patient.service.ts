import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor() { }

  patientColumnDefs = [
    {headerName: 'First Name', field: 'firstName', sortable: true, filter: true},
    {headerName: 'Last Name', field: 'lastName', sortable: true, filter: true},
    {headerName: 'Visits', field: 'visits', sortable: true, filter: true},
    {headerName: 'Age', field: 'age', sortable: true, filter: true},
    {headerName: 'Physician', field: 'pcp', sortable: true, filter: true},
    {headerName: 'Insurance', field: 'insurance', sortable: true, filter: true}
  ];

  patientData = [
    { firstName: 'John',    lastName: 'Babu',        visits: 2, age: 36,  pcp: 'Andrew',   insurance: 'uhc' , payement: 0},
    { firstName: 'Jessin',  lastName: 'Babu',         visits: 4, age: 7,   pcp: 'Aeron',    insurance: 'aetna', payement: 0},
    { firstName: 'Jannis',  lastName: 'Babu',         visits: 6, age: 5,   pcp: 'Antony',   insurance: 'cigna', payement: 0},
    { firstName: 'Jenifer', lastName: 'Babu',         visits: 5, age: 33,  pcp: 'Elyse',    insurance: 'bluecross', payement: 0},
    { firstName: 'Sadeesh', lastName: 'Ramakrishnan', visits: 2, age: 38,  pcp: 'Gerald',   insurance: 'aetna', payement: 0},
    { firstName: 'Anita',   lastName: 'Ramakrishnan',      visits: 8, age: 35,  pcp: 'Micheal',  insurance: 'uhc', payement: 0 },
    { firstName: 'Prithvi', lastName: 'Ramakrishnan',      visits: 3, age: 4,   pcp: 'Connie',   insurance: 'cigna', payement: 0 },
    { firstName: 'Ram',     lastName: 'MM',           visits: 7, age: 33,  pcp: 'Andrew',   insurance: 'bluecross', payement: 0},
    { firstName: 'Santhya', lastName: 'MM',          visits: 8, age: 28,  pcp: 'Antony',   insurance: 'uhc', payement: 0},
    { firstName: 'Madhav',  lastName: 'MM',          visits: 3, age: 5,   pcp: 'Gerald',   insurance: 'cigna', payement: 0 },
    { firstName: 'Mithran', lastName: 'MM',          visits: 10, age: 1,   pcp: 'Aeron',    insurance: 'aetna', payement: 0 }
  ];

}