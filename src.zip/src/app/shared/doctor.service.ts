import { Injectable } from '@angular/core';
import { DoctorModel } from './doctor.model';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {

  constructor() { }

  // doctorColumnDefs = [
  //   {headerName: 'First Name', field: 'firstName', sortable: true, filter: true},
  //   {headerName: 'Last Name', field: 'lastName', sortable: true, filter: true},
  //   {headerName: 'Rating', field: 'rating', sortable: true, filter: true},
  //   {headerName: 'Age', field: 'age', sortable: true, filter: true},
  //   {headerName: 'Experience', field: 'experience', sortable: true, filter: true},
  //   {headerName: 'Insurance', field: 'insurance', sortable: true, filter: true}
  // ];
  refreshDoctors = new Subject<{firstName: string,
    lastName: string,
    rating: number,
    age: number,
    experience: number,
    insurance: string}[]
    >();

    AddDoc = [];

  doctorColumnDefs = ['firstName', 'lastName', 'rating', 'age', 'experience', 'insurance', 'update'];
  doctorData = [
    new DoctorModel('Gregory', 'Lam', 5, 45, 10, 'uhc'),
    new DoctorModel('Aeron', 'Shaftel', 4, 51, 15, 'aetna'),
    new DoctorModel('Connie', 'Gowrich', 5, 55, 12, 'cigna'),
    new DoctorModel('Andrew', 'Jofrdon', 2, 43, 14, 'bluecross'),
    new DoctorModel('Antony', 'Phillips',  5, 50, 13, 'uhc'),
    new DoctorModel('Gerald', 'Arnett', 4, 49, 12, 'aetna'),
    new DoctorModel('Elyse', 'Schutle', 5, 46, 10, 'cigna'),
    new DoctorModel('Micheal', 'Cornett', 2, 43, 14, 'bluecross')
  ];

  getAllDoctors() {
    return this.doctorData;
  }

  updateDoctorDetail(updatedDoctor: any) {
    this.doctorData = this.doctorData.map(doctor => {
      if (doctor.firstName === updatedDoctor.firstName) {
        return updatedDoctor;
      } else {
        return doctor;
      }
    });
    this.refreshDoctors.next(this.doctorData);
  }

  addNewDoctor(newDoctor: any) {
    debugger;
    this.doctorData.push(newDoctor);
    this.refreshDoctors.next(this.doctorData);
  }


}