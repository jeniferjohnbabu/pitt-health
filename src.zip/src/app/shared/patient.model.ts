export class PatientModel {
    constructor(
        public firstName: string,
        public lastName: string,
        public visists: number,
        public age: number,
        public pcp: string,
        public insurance: string,
        public payment: number
    ) {}
}