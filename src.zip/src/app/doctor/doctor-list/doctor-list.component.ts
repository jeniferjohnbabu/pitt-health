import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { DoctorService } from 'src/app/shared/doctor.service';
import { MatDialog } from '@angular/material/dialog';
import { ViewDoctorComponent } from '../view-doctor/view-doctor.component';
import { DoctorModel } from 'src/app/shared/doctor.model';
import { UpdateDoctorComponent } from '../update-doctor/update-doctor.component';
import { AddDoctorComponent } from '../add-doctor/add-doctor.component';
import { MatTableDataSource } from '@angular/material/table';
import { DeleteDoctorComponent } from '../delete-doctor/delete-doctor.component';

@Component({
  selector: 'app-doctor-list',
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.css']
})
export class DoctorListComponent implements OnInit {
  displayedColumns = [];
  dataSource = new MatTableDataSource<DoctorModel>();
  constructor(private doctorService: DoctorService,
              public dialog: MatDialog,
              private changeDetectorRefs: ChangeDetectorRef) {}

  ngOnInit() {
    this.displayedColumns = this.doctorService.doctorColumnDefs;
    this.dataSource.data = this.doctorService.getAllDoctors();
    this.doctorService.refreshDoctors.subscribe(doctors => {
      this.dataSource.data = doctors;
    });
  }

  openDialog(selectedDoctor: DoctorModel) {
    const dialogRef = this.dialog.open(ViewDoctorComponent, {
      height: '400px',
      width: '600px',
      data: selectedDoctor
    });
  }

  onEditDoctor(doctor: DoctorModel) {
    const dialogRef = this.dialog.open(UpdateDoctorComponent, {
      height: '400px',
      width: '600px',
      data: doctor
    });
    dialogRef.afterClosed().subscribe(result => {
      this.doctorService.updateDoctorDetail(result);
    });
  }

  onAddDoctor() {
    const dialogRef = this.dialog.open(AddDoctorComponent, {
      height: '90%',
      width: '90%'
    });
    dialogRef.afterClosed().subscribe(result => {
      this.doctorService.addNewDoctor(result);
    });
  }

  onRemoveDoctor(selectedDoctor: DoctorModel){
    const dialogRef = this.dialog.open(DeleteDoctorComponent, {
      height: '400px',
      width: '600px',
      data: selectedDoctor
    });
  }
}
